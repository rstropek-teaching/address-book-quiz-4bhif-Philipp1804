export interface ICustomer {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
  }
  
export const customers: ICustomer[] = [
    {id: 1, firstName: 'Philipp', lastName: 'Diesenreither', email: "philipp.diesenreither2000@gmail.com"},
    {id: 2, firstName: 'Beate', lastName: 'Lasinger',email: "beate.lasinger@aon.at"},
    {id: 3, firstName: 'Kevin', lastName: 'Wahlmüller',email: "kevin123@gmail.com"},
    {id: 4, firstName: 'Tobias', lastName: 'Fragner',email: "fragner123@gmail.com"},
    {id: 5, firstName: 'Lena', lastName: 'Leonhartsberger',email: "lena.leonhartsberger@gmail.com"},
    {id: 6, firstName: 'Lisa', lastName: 'Diesenreiter',email: "lisa.maria.diesenreiter@gmail.com"},
    {id: 7, firstName: 'Jakob', lastName: 'Strasser',email: "jakob.strasser@yahoo.com"},
    {id: 8, firstName: 'Kersitin', lastName: 'Diesenreither',email: "kerstin.diesnreither@a1.at"}
  ];
