import {createServer, plugins} from 'restify';
import {deleteSingle} from './delete';
import {get} from './get';
import {getONE} from './getOne';
import {post} from './post';

var server = createServer();

server.use(plugins.bodyParser());

server.get('/api/contacts', get);
server.post('/api/contacts', post);
server.get('/api/contacts/:id', getOne);
server.del('/api/contacts/:id', deleteSingle);

server.listen(5000, () => console.log('API is online'));